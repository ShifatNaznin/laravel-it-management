<i class="fa fa-shopping-basket" aria-hidden="true"></i><span class="badge badge-info"
        style="background: rgb(59, 202, 245);">{{Cart::count()}}</span>