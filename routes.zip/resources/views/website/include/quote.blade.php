<div class="gb-holder">
    <div class="container">
        <div class="grey-border w-88"></div>
    </div>
</div>

<section id="languages-1" class="bg-deepblue bg-pattern wide-100 languages-section division">
    <div class="container white-color">



        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <div class="section-title text-center mb-50">

                    <!-- Title -->
                    <h3 class="h3-xl">REQUEST A QUOTATION</h3>

                </div>
            </div>
        </div>


        <!-- FLAGS -->
        <div class="row">
            <div class="col-md-12 text-center">


                <!-- Buttons Group -->
                <div class="btns-group">

                    <p>Need a solution for your business? Provide us with your information, we will be more than
                        happy to provide you with a quotation.</p>

                    <a href="#" class="btn btn-md btn-tra-white black-hover">Quote</a>

                    <!-- Text -->

                </div>


            </div>
        </div> <!-- END FLAGS -->


    </div>
</section>
