<section id="screens-1" class="bg-dark wide-100 screens-section division">



    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title mb-80 white-color">

                    <!-- Title 	-->
                    <h2 class="h2-xs">Projects</h2>

                    <!-- Text -->
                    <p class="p-xl">Lorem ipsum dolor sit amet consectetur adipisicing elit. At, accusantium!
                    </p>

                </div>
            </div>
        </div>
    </div>


    <!-- SCREENSHOTS CAROUSEL -->
    <div class="screenshots-wrap">
        <div class="screens-carousel">


            <!-- Screen #1 -->
            <div class="screen-preview">
                <img src="{{asset('contents/website')}}/assets/images/aa.jpg" alt="screenshot">
            </div>

            <!-- Screen #2 -->
            <div class="screen-preview">
                <img src="{{asset('contents/website')}}/assets/images/aa.jpg" alt="screenshot">
            </div>

            <!-- Screen #3 -->
            <div class="screen-preview">
                <img src="{{asset('contents/website')}}/assets/images/aa.jpg" alt="screenshot">
            </div>

            <!-- Screen #4 -->
            <div class="screen-preview">
                <img src="{{asset('contents/website')}}/assets/images/aa.jpg" alt="screenshot">
            </div>

            <!-- Screen #5 -->
            <div class="screen-preview">
                <img src="{{asset('contents/website')}}/assets/images/aa.jpg" alt="screenshot">
            </div>

            <!-- Screen #6 -->
            <div class="screen-preview">
                <img src="{{asset('contents/website')}}/assets/images/aa.jpg" alt="screenshot">
            </div>

            <!-- Screen #7 -->
            <div class="screen-preview">
                <img src="{{asset('contents/website')}}/assets/images/aa.jpg" alt="screenshot">
            </div>

            <!-- Screen #8 -->
            <div class="screen-preview">
                <img src="{{asset('contents/website')}}/assets/images/aa.jpg" alt="screenshot">
            </div>


        </div>
    </div> <!-- END SCREENSHOTS CAROUSEL -->


</section> 