<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FooterTwo extends Model
{
    //
}
