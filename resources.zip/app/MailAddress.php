<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MailAddress extends Model
{
    //
}
