<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hosting_title extends Model
{
    //
}
