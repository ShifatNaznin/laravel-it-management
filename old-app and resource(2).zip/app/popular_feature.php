<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class popular_feature extends Model
{
    //
}
