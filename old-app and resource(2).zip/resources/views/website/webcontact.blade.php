<div class="plan-name">
    <h2>Platinum</h2>
    <h4>Monthly Plan</h4>
</div>